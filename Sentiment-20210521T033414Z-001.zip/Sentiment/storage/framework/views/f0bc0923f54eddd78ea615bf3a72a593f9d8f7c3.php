<section class="content">
    <div class="container-fluid">
  
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <?php echo Form::open(['route' => 'import.store', 'method' => 'POST', 'files' => true, 'data-parsley-validate'=>'']); ?>


                <div class="form-group">
                    <?php echo e(Form::label('path', 'Path')); ?>

                    <?php echo e(Form::file('path',array('class' => 'form-control'))); ?>

                </div>
    
                 <?php echo e(Form::submit('Create', array('class' => 'btn btn-success'))); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
  </section>
  
<p>
    <strong>Result: </strong> <br>
    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>Positive: <?php echo e($con['pos']); ?></p>
        <p>Negative: <?php echo e($con['neg']); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p><?php /**PATH E:\intern\program\ComposerSetup\Sentiment\resources\views/importex.blade.php ENDPATH**/ ?>