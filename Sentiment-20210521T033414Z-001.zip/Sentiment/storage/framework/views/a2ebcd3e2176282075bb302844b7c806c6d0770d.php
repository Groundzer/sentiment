

<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1 class="mt-5 pt-5">Data Analyzer</h1>
        <div class="jumbotron text-center">
            <p>
                <strong>Title: </strong> <?php echo e($file->path); ?> <br>
                <strong>Create at: </strong><?php echo e($file->created_at); ?>

            </p>
        </div>

    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\intern\program\ComposerSetup\Sentiment\resources\views/show.blade.php ENDPATH**/ ?>