


<?php $__env->startSection('content'); ?>

    <div class="container mt-5 pt-5">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
        <div class="container-fluid d-flex justify-content-center">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <?php echo Form::open(['route' => 'import.store', 'method' => 'POST', 'files' => true, 'data-parsley-validate'=>'']); ?>

        
                    <div class="form-group d-flex justify-content-center">
                        <?php echo e(Form::label('path', 'Upload Your File.csv')); ?>

                        <?php echo e(Form::file('path',array('class' => 'form-control'))); ?>

                    </div>
                    <?php echo e(Form::submit('SUBMIT', array('class' => 'btn btn-success'))); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
        <table class="table mt-5 pt-5">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">File</th>
                    <th scope="col">Timestamp</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="/import/<?php echo e($file->id); ?>"><?php echo e($file->path); ?></a></td>
                        <td><?php echo e($file->created_at->format('Y-m-d H:i:s')); ?></td>
                        <td>
                            <form action="<?php echo e(url('import', [$file->id])); ?>" method="post">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="submit" class="btn btn-danger" value="Delete">
                            </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\intern\program\ComposerSetup\Sentiment\resources\views//index.blade.php ENDPATH**/ ?>