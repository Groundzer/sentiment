<section class="content">
    <div class="container-fluid">
  
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                {!! Form::open(['route' => 'import.store', 'method' => 'POST', 'files' => true, 'data-parsley-validate'=>'']) !!}

                <div class="form-group">
                    {{ Form::label('path', 'Path') }}
                    {{ Form::file('path',array('class' => 'form-control')) }}
                </div>
    
                 {{ Form::submit('Create', array('class' => 'btn btn-success')) }}
                {!! Form::close() !!}
            </div>
        </div>
    </div>
  </section>
  
<p>
    <strong>Result: </strong> <br>
    @foreach ($content as $con)
        <p>Positive: {{$con['pos']}}</p>
        <p>Negative: {{$con['neg']}}</p>
    @endforeach
</p>