@extends('layout.mainlayout')

@section('content')

    <div class="container">
        <h1 class="mt-5 pt-5">Data Analyzer</h1>
        <div class="jumbotron text-center">
            <p>
                <strong>Title: </strong> {{$file->path}} <br>
                <strong>Create at: </strong>{{$file->created_at}}
            </p>
        </div>

    </div>
    
@endsection