
@extends('layout.mainlayout')

@section('content')

    <div class="container mt-5 pt-5">
        @if (Session::has('message'))
            <div class="alert alert-info">{{Session::get('message')}}</div>
        @endif
        <div class="container-fluid d-flex justify-content-center">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    {!! Form::open(['route' => 'import.store', 'method' => 'POST', 'files' => true, 'data-parsley-validate'=>'']) !!}
        
                    <div class="form-group d-flex justify-content-center">
                        {{ Form::label('path', 'Upload Your File.csv') }}
                        {{ Form::file('path',array('class' => 'form-control')) }}
                    </div>
                    {{ Form::submit('SUBMIT', array('class' => 'btn btn-success')) }}
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
        <table class="table mt-5 pt-5">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">File</th>
                    <th scope="col">Timestamp</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($files as $file)
                    <tr>
                        <th scope="row">{{$file->id}}</th>
                        <td><a href="/import/{{$file->id}}">{{$file->path}}</a></td>
                        <td>{{$file->created_at->format('Y-m-d H:i:s')}}</td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Basic example">
                            <form action="{{url('import', [$file->id])}}" method="post">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                <input type="submit" class="btn btn-danger" value="Delete">
                            </form>
                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

@endsection
