<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;


class test2Controller extends Controller
{
    public function testPythonScript()
    {
        $analyzer = new Analyzer();
        $sentence = "i don't like it";
        $result = $analyzer->getSentiment($sentence);
        print_r($result);
        $process = new process(["D:/Anaconda/envs/snakes/python.exe", "e:/intern/program/ComposerSetup/Sentiment/app/pythonscript/test.py"]);
        $process->start();

        while ($process->isRunning()) {
            echo $process->getOutput();
        // waiting for process to finish
        }

        echo $process->getOutput();
        #echo $process->getOutput();
        echo 'run man'; 
        ///return view('test')->with('process', $process);
    }
}
