<?php

namespace App\Http\Controllers;
use Storage;
use Illuminate\Http\Request;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;

class testController extends Controller
{
    public function testPythonScript()
    {

        $process = shell_exec("D:/Anaconda/envs/snakes/python.exe e:/intern/program/ComposerSetup/Sentiment/app/pythonscript/run_predict.py 2>&1");
        
        #echo $process;
        
        #Storage::put('Data_Result.json', $process);
        $path = 'E:\intern\program\ComposerSetup\Sentiment\public\result_data.json';
        $content = json_decode(file_get_contents($path), true);

        return view('index', compact('content', $content));
       
    }
}
