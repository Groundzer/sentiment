<?php

namespace App\Http\Controllers;

use App\Import;
use Illuminate\Http\Request;
use Storage;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class importController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    

    public function index()
    {   
        $files = Import::all();

        return view('index', compact('files', $files));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('importex');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $formInput=$request->except('path');
        $path=$request->path;
        if($path){
            $pathName=$path->getClientOriginalName();
            $path->move('csvfile',$pathName);
            $formInput['path']=$pathName;
        }
        $file = Import::create($formInput);
        return redirect('/import/'.$file->id);
        #return redirect()->route('import.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Import  $file
     * @return \Illuminate\Http\Response
     */
    public function show(Import $file)
    {
        echo $file;
        return view('show', compact('file', $file));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Import  $file
     * @return \Illuminate\Http\Response
     */
    public function edit(Import $file)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Import  $file
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Import $file)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Import  $file
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Import $file)
    {
        $file->DELETE();
        $request->session()->flash('message', "DELETE");
        return redirect('import');
    }
}
