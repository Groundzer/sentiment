# User inputs the string and it gets stored in variable str
import json
str = "Enter a strinsqqqqqqqqqqg: "

# counter variable to count the character in a string
counter = 0
for s in str:
      counter = counter+1

#print("Length of the input string is:")
mylist = {'get1' : counter, 'get2' :'42222222222222222222222'}
print(json.dumps(mylist))