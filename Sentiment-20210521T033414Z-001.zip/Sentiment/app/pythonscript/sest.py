import codecs
import json
import sys
# sys.setdefaultencoding() does not exist, here!
reload(sys)  # Reload does the trick!
sys.setdefaultencoding('UTF8')

f = codecs.open('E:\intern\program\ComposerSetup\Sentiment\\app\pythonscript\\readtest.json', encoding='utf-8')
data = json.load(f)

#textfile = codecs.open("E:\intern\program\ComposerSetup\Sentiment\\app\pythonscript\\readtest.txt")
#i = textfile.read().encode()
#i = data["Data"]["pos"].encode()
i = data["Data"]["pos"]
#i = i.encode()
print(i)