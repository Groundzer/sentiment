import joblib
import pandas as pd
#import pythainlp
#from deepcut import tokenize
from pythainlp.tokenize import word_tokenize
from itertools import chain
import codecs
import re
import json

pattern = '\ufeff'

df = pd.read_csv('E:\intern\program\ComposerSetup\Sentiment\public\csvfile\data_sentiment.csv')
#print(df.head())

filename = 'finalized_model.sav'
loaded_model = joblib.load(filename)
    
textfile = open("pos.txt", "r", encoding='utf-8')
i = textfile.read()
i = re.sub(pattern, '', i)
list_pos = i.split(",")
#print(list_pos)
textfile.close()

textfile = open("neg.txt", "r", encoding='utf-8')
i = textfile.read()
i = re.sub(pattern, '', i)
list_neg = i.split(",")
#print(list_neg)
textfile.close()

pos1=['pos']*len(list_pos)
neg1=['neg']*len(list_neg)
training_data = list(zip(list_pos,pos1)) + list(zip(list_neg,neg1))
vocabulary = set(chain(*[word_tokenize(i[0].lower()) for i in training_data]))
'''
textfile = codecs.open("vocab.txt", "w", encoding='utf-8')
for element in vocabulary:
      #print(element)
      textfile.write(element)
      textfile.write(",")
textfile.close()
'''

result = {"Data": { "pos": 0, "neg": 0 }}
for test_sentence in df.sentiment:
      #print(test_sentence)
      featurized_test_sentence =  {i:(i in word_tokenize(test_sentence.lower())) for i in vocabulary}
      print(type(featurized_test_sentence))
      tag = loaded_model.classify(featurized_test_sentence)
      if tag == 'pos':
            result["Data"]["pos"] += 1
      else:
            result["Data"]["neg"] += 1
    
print(result)
textfile = open("result_data.json", "w", encoding='utf-8')
#print(type(json.dumps(result)))
textfile.write(json.dumps(result))
textfile.close()

