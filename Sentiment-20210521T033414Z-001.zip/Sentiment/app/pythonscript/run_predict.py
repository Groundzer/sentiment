
import joblib
import pandas as pd
import codecs
import re
import json
from pythainlp.tokenize import word_tokenize
import pickle
pattern = '\ufeff'

df = pd.read_csv('E:\intern\program\ComposerSetup\Sentiment\public\csvfile\data_sentimentV2.csv')
#print(df.head())
#print("run")
filename = 'E:\intern\program\ComposerSetup\Sentiment\\app\pythonscript\\finalized_model.sav'
#loaded_model = joblib.load(filename)
loaded_model = pickle.load(open(filename, 'rb'))

textfile = open("E:\intern\program\ComposerSetup\Sentiment\\app\pythonscript\\vocab.txt", "r", encoding='utf-8')
i = textfile.read()
#print(i)
i = re.sub(pattern, '', i)
set_vocab = set(i.split(","))
set_vocab.remove("")
#print(set_vocab)
#print(len(set_vocab), type(set_vocab))
textfile.close()

result = {"Data": { "pos": 0, "neg": 0 }}
for test_sentence in df.sentiment:
      #print(test_sentence)
      test_sentence = str(test_sentence)
      featurized_test_sentence =  {i:(i in word_tokenize(test_sentence.lower())) for i in set_vocab}
      tag = loaded_model.classify(featurized_test_sentence)
      if tag == 'pos':
            result["Data"]["pos"] += 1
      else:
            result["Data"]["neg"] += 1

#print(str(result))
textfile = open("E:\intern\program\ComposerSetup\Sentiment\public\\result_data.json", "w")
#print(type(json.dumps(result)))
textfile.write(json.dumps(result))
textfile.close()